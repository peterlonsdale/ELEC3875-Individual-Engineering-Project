from openai import OpenAI
import json
# from Recommender3 import recommend_restaurant
from Recommender5 import recommend_restaurant

""" 
This function returns a response to the user's prompt, and can also provide recommendations assuming the requirements are met

Argument -- user input
Return: response or recommendations

"""


def chatbot(user_input):
    client = OpenAI(
        api_key="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"
    )
    prompt = user_input
    # print(prompt)

    # Construct the arguments section dynamically
    arguments = {
        "preferred_cuisines": "Mexican,American",
        "preferred_state": "NY"
    }
    # Where the response is generated
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": prompt},
            {"role": "user", "content": ""}
        ],
        tools=[
            {
                "type": "function",
                "function": {
                    "name": "recommend_restaurant",
                    "description": "Return a string of the top 5 restaurants that match the given cuisine types and state",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "preferred_cuisines": {
                                "type": "string",
                                "description": "The types of cuisines specified by the user separated by a comma without spaces",
                            },
                            "preferred_state": {
                                "type": "string",
                                "description": "The state code e.g. for New York the input would be NY",
                            },
                        },
                        "required": ["preferred_cuisines", "preferred_state"],
                    },
                },
                "arguments": arguments  # Pass the dynamically determined arguments here
            }
        ]
    )

    response_message = response.choices[0].message
    tool_calls = response_message.tool_calls

    if tool_calls:
        # Call the function
        available_functions = {
            "recommend_restaurant": recommend_restaurant,
        }
        # Send the info for each function call and function response to the model
        for tool_call in tool_calls:
            function_name = tool_call.function.name
            function_to_call = available_functions[function_name]
            function_args = json.loads(tool_call.function.arguments)
            function_response = function_to_call(
                preferred_cuisines=function_args.get("preferred_cuisines"),
                preferred_state=function_args.get("preferred_state"),
            )
            return function_response  # Return the response from the recommendation function
    else:
        return response_message.content



if __name__ == "__main__":
    prompt = input("enter your query please: ")
    response = chatbot(prompt)
    # if hasattr(response,'content'):
    #     print(response.content)
    # else:
    #     print(response)
    print(response)
