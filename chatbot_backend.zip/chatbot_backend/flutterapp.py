from flask import Flask, request, jsonify
from chatbot_OpenAI import chatbot


app = Flask(__name__)


@app.route('/', methods=['GET','POST'])
def chatbot_manager():
    if request.method == 'GET':
        query = request.args.get('query')
        print(query)
        response = chatbot(query)
        if hasattr(response,'content'):
            return jsonify({'response':f'{response.content}'})
        else:
            return jsonify({'response':f'{response}'})
    else:
        return jsonify({'response':'this if flask'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)


























