import firebase_admin
from firebase_admin import credentials, firestore
import pandas as pd

# # Initialize Firebase Admin
# cred = credentials.Certificate("test-ltf-key.json")  # Path to service account key JSON file
# firebase_admin.initialize_app(cred)

# # Create a Firestore client
# db = firestore.client()

def recommend_restaurant(preferred_cuisines, preferred_state):
    # Initialize Firebase Admin
    cred = credentials.Certificate("test-ltf-key.json")  # Path to service account key JSON file
    firebase_admin.initialize_app(cred)

    # Create a Firestore client
    db = firestore.client()
    print("Executing recommend_restaurant function...")
    print("Preferred cuisines:", preferred_cuisines)
    print("Preferred state:", preferred_state)

    # Reference to the 'Recommendation_data' collection in Firestore
    recommendation_ref = db.collection('Recommendation_data')

    # Query all documents in the 'Recommendation_data' collection
    docs = recommendation_ref.stream()

    # Convert the query result into a DataFrame
    data = []
    for doc in docs:
        data.append(doc.to_dict())
    df = pd.DataFrame(data)

    # Convert 'Type' column to strings before joining
    df['Combined_Cuisines'] = df.groupby('Name')['Type'].transform(lambda x: ', '.join(str(val) for val in x))

    # Calculate the similarity based on the number of matching preferred cuisines
    df['Cuisine_Similarity'] = df['Combined_Cuisines'].apply(lambda x: sum(cuisine in x for cuisine in preferred_cuisines))

    # Convert 'Reviews' and 'No of Reviews' columns to numeric, handling errors and replacing with 0
    df['Reviews'] = pd.to_numeric(df['Reviews'], errors='coerce').fillna(0)
    df['No'] = pd.to_numeric(df['No'], errors='coerce').fillna(0)

    # Weighted Rating: Multiply the rating by the square root of the number of reviews
    df['Weighted_Rating'] = df['Reviews'] * df['No'].apply(lambda x: (x + 1) ** 0.5)

    # Filter restaurants by the preferred state
    if preferred_state:
        df['State'] = df['Location'].apply(lambda x: x.split()[-1].capitalize() if isinstance(x, str) and x.split() else None)
        df = df[df['State'] == preferred_state.capitalize()]


    # Sort the DataFrame based on cuisine similarity and weighted rating in descending order
    result_df = df.sort_values(by=['Cuisine_Similarity', 'Weighted_Rating'], ascending=[False, False]).reset_index(drop=True)

    # Keep track of selected restaurants to avoid duplicates
    selected_restaurants = set()

    # Get the top 5 matching restaurants without duplicates
    top_restaurants = []
    for i, row in result_df.iterrows():
        if row['Name'] not in selected_restaurants and len(top_restaurants) < 5:
            selected_restaurants.add(row['Name'])
            top_restaurants.append(row)

    # Prepare recommendation message
    recommendation_message = f"The top 5 matching restaurants for {''.join(preferred_cuisines)} cuisines in {preferred_state} are:\n\n"
    for i, row in enumerate(top_restaurants, start=1):
        recommendation_message += f"{i}. {row['Name']} (Cuisine Similarity: {row['Cuisine_Similarity']}, Weighted Rating: {row['Weighted_Rating']:.2f})\n"

    return recommendation_message

# # Get user input
# user_preferred_cuisines = input("Enter your preferred cuisines (comma-separated): ").split(',')
# preferred_state = input("Enter your preferred state (or leave blank for any): ").capitalize()

# # Get restaurant recommendations
# recommendation = recommend_restaurant(user_preferred_cuisines, preferred_state)
# print(recommendation)
