import firebase_admin
from firebase_admin import credentials, firestore

# Initialize Firebase Admin SDK
cred = credentials.Certificate("test-ltf-key.json")  # Path to service account key
firebase_admin.initialize_app(cred)

# Get a reference to the Firestore database
db = firestore.client()

def list_subcollection_documents(collection_name, document_id, subcollection_name):
    try:
        # Reference to the subcollection
        subcollection_ref = db.collection(collection_name).document(document_id).collection(subcollection_name)
        
        # Get all documents in the subcollection
        docs = subcollection_ref.stream()
        
        # Initialize an empty list to store comments
        comments = []
        
        # Iterate through each document in the subcollection
        for doc in docs:
            # Access specific fields from the document and append them to the comments list
            comment_data = doc.to_dict()
            comments.append(comment_data.get("comment"))  # Field to retrieve
        
        # Concatenate the comments into a single string separated by newlines
        comments_str = '\n'.join(comments)
        
        return comments_str
            
    except Exception as e:
        return ('Error listing documents:', e)


collection_name = 'sellers'  # Name of collection
query_field = '6JgCL7BPwvU8Llcjoz8C01x24fG3'  # Field to query
query_value = 'comments'  # Value to match

str = list_subcollection_documents(collection_name, query_field, query_value)
print(str)
