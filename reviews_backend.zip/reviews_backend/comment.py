from flask import Flask, request, jsonify
from query_firestore import list_subcollection_documents
from add_comments_orderID import add_comment_to_seller

collection_name = 'sellers'
query_value = 'comments'

app = Flask(__name__)

# Route for GET requests that retrieves comments from the database
@app.route('/', methods=['GET'])
def get_comments():
    if request.method == 'GET':
        # Get sellerUID from query parameters
        sellerUID = request.args.get('sellerUID')
        
        if sellerUID:
            # Process the data
            processed_data = list_subcollection_documents(collection_name, sellerUID, query_value)
            print(processed_data)
            return jsonify(processed_data)
        else:
            return 'Error: Missing sellerUID parameter', 400

# Route for GET requests that add coments to the database
@app.route('/addComment', methods=['GET'])
def add_comment():
    if request.method == 'GET':
        # Get orderID and review fro query parameters
        orderID = request.args.get('orderID')
        comment = request.args.get('comment')
        #add comment
        if orderID and comment:
            add_comment_to_seller(orderID,comment)
            return 200
        else:
            return 400

if __name__ == '__main__':
    app.run(debug=True)
