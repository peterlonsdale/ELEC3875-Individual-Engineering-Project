import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Initialize Firebase Admin SDK
# cred = credentials.Certificate("test-ltf-key.json")
# firebase_admin.initialize_app(cred)

def add_comment_to_seller(order_id, comment):
    # Initialize Firestore client
    db = firestore.client()

    # Retrieve the seller UID for the given order ID
    order_ref = db.collection('orders').document(order_id)
    order_doc = order_ref.get()
    
    if order_doc.exists:
        seller_uid = order_doc.get('sellerUID')

        # Add comment to seller
        seller_ref = db.collection('sellers').document(seller_uid).collection('comments').document()
        seller_ref.set({
            'comment': comment
        })
        print("Comment added successfully!")
    else:
        print("Order ID not found.")

# Test usage
order_id = "1685523105103"
comment = "Great seller, fast shipping!"
add_comment_to_seller(order_id, comment)
